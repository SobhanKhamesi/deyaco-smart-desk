<script setup>
import { ref } from 'vue'
import AppHeader from '@/components/layout/header/AppHeader.vue'
import AppDrawer from '@/components/layout/drawer/AppDrawer.vue'

const drawerOpen = ref(true)
</script>

<template>
  <q-layout view="lhr Lpr lFr"
  >
    <app-header @toggle-drawer="drawerOpen = !drawerOpen" />
    <app-drawer v-model="drawerOpen" />
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>
