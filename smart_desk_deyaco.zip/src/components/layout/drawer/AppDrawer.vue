<script setup>
import {drawerMenu} from '@/config/drawerMenu.js'
import AppDrawerItem from './AppDrawerItem.vue'

const modelValue = defineModel({type: Boolean, default: true})


const thumbStyle = {
  borderRadius: '5px',
  backgroundColor: '#303030',
  width: '6px',
  opacity: 0.5
}

const barStyle = {
  borderRadius: '9px',
  backgroundColor: 'transparent',
  width: '9px',
  opacity: 0.2
}
</script>

<template>
  <q-drawer
    v-model="modelValue"
    :width="265"
    class="app-drawer bg-secondary"
    style="
      box-shadow: 1px 0 20px 0 #3f4d67;
"
  >
    <q-scroll-area
      :horizontal-offset="[0, 5]"
      :thumb-style="thumbStyle"
      :bar-style="barStyle"
      style="height: 100vh;max-width: 300px"
    >
      <div class="app-drawer__top">
        <q-avatar class="app-drawer__avatar" size="35px" rounded>
          <!--        <q-icon name="bi-person-fill" size="20px" />-->
        </q-avatar>

        <q-space/>

        <q-btn
          flat
          round
          dense
          icon="eva-bar-chart-outline"
          class="app-drawer__toggle rotate-90"
          aria-label="جمع کردن منو"
          @click="modelValue = !modelValue"
        />
      </div>

      <q-list>
        <app-drawer-item v-for="item in drawerMenu" :key="item.id" :item="item"/>
      </q-list>
    </q-scroll-area>
  </q-drawer>
</template>

<style scoped>
.app-drawer :deep(.q-drawer__content) {
  background: var(--sidebar-bg);
  display: flex;
  flex-direction: column;
}

.app-drawer__top {
  display: flex;
  align-items: center;
  padding: 14px 16px;
  flex: none;
}

.app-drawer__avatar {
  background: linear-gradient(135deg, var(--sidebar-avatar-start), var(--sidebar-avatar-end));
  color: #fff;
  border-radius: 11px !important;
}

.app-drawer__toggle {
  color: var(--sidebar-item-color);
}

.app-drawer__scroll {
  flex: 1 1 auto;
}
</style>
