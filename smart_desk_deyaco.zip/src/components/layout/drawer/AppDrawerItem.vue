<script setup>
import { ref } from 'vue'

defineProps({
  item: {
    type: Object,
    required: true
  }
})

/* Local open state drives the active-row highlight — Quasar itself tracks
   route-based active state on the leaf q-item below via q-router-link--active. */
const opened = ref(false)
</script>

<template>
    <q-expansion-item
      v-if="item.children"
      v-model="opened"
      group="side-bar-nav"
      :header-class="['drawer-item', { 'drawer-item--active': opened }]"
      expand-icon-class="drawer-item__expand-icon"
      label="">
      <template v-slot:header>
        <q-item-section avatar>
          <q-icon size="16px" :name="item.icon"/>
        </q-item-section>
        <q-item-section>
          <span>{{item.label}}</span>
        </q-item-section>
      </template>
    <q-list class="drawer-subitems">
      <q-item
        v-for="child in item.children"
        :key="child.id"
        clickable
        v-ripple
        :to="child.to"
        class="drawer-item drawer-item--child q-py-md"
      >
        <q-item-section>{{ child.label }}</q-item-section>
      </q-item>

      <div v-if="!item.children.length" class="drawer-subitems__empty">
        زیرمنویی ثبت نشده است
      </div>
    </q-list>
  </q-expansion-item>

  <q-item
    v-else
    clickable
    v-ripple
    :to="item.to"
    :header-class="['drawer-item', { 'drawer-item--active': opened }]"
    expand-icon-class="drawer-item__expand-icon"
    class="drawer-item"
  >
    <q-item-section avatar class="drawer-item__icon">
      <q-icon :name="item.icon" size="16px"/>
    </q-item-section>
    <q-item-section>{{ item.label }}</q-item-section>
  </q-item>
</template>

<style scoped>
.drawer-item {
  color: var(--sidebar-item-color);
  min-height: 48px;
}

:deep(.drawer-item) {
  color: var(--sidebar-item-color);
  min-height: 48px;
}

:deep(.drawer-item .q-item__section--avatar) {
  min-width: 34px;
  color: inherit;
}

:deep(.drawer-item:hover) {
  background: var(--sidebar-item-bg-hover);
}

:deep(.drawer-item.q-router-link--active),
:deep(.drawer-item--active) {
  background: var(--sidebar-item-bg-active);
  color: var(--sidebar-item-color-active);
  font-weight: 500;
  border-inline-start: 3px solid var(--sidebar-active-bar);
}

:deep(.drawer-item__expand-icon) {
  color: inherit;
}

.drawer-subitems {
  background: var(--sidebar-subitem-bg);
}

.drawer-subitems :deep(.drawer-item--child) {
  padding-inline-start: 48px;
  min-height: 40px;
  border-inline-start: 3px solid var(--sidebar-active-bar);
  font-size: 13px;
}

.drawer-subitems__empty {
  padding: 8px 48px;
  font-size: 12px;
  color: var(--sidebar-item-color);
  border-inline-start: 3px solid var(--sidebar-active-bar);
  opacity: 0.6;
}
</style>
