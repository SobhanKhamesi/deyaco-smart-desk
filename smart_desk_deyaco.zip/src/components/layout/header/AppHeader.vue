<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useQuasar } from 'quasar'
import { useRoute } from 'vue-router'
import HeaderDropdownStat from '@/components/layout/header/buttons/HeaderDropdownStat.vue'
import HeaderOnlineCreditButton from '@/components/layout/header/buttons/HeaderOnlineCreditButton.vue'
import HeaderBalanceButton from '@/components/layout/header/buttons/HeaderBalanceButton.vue'

defineEmits(['toggle-drawer'])

const $q = useQuasar()
const route = useRoute()

/** Page title: falls back to the app name when a route has none set. */
const pageTitle = computed(() => route.meta.title || 'شرکت رز رنگ نساج ایساتیس')

function toggleFullscreen () {
  $q.fullscreen.toggle()
}

/* Demo session clock, standing in for whatever "۱۴:۲۹" represents in the
   original app (session time-left, last sync time, etc). Swap the
   `updateClock` body for real data once you know what it should show. */
const clockLabel = ref('')
let clockTimer = null

function updateClock () {
  clockLabel.value = new Date().toLocaleTimeString('fa-IR', {
    hour: '2-digit',
    minute: '2-digit'
  })
}

onMounted(() => {
  updateClock()
  clockTimer = setInterval(updateClock, 30_000)
})

onUnmounted(() => clearInterval(clockTimer))
</script>

<template>
  <q-header class="app-header">
    <q-toolbar class="app-header__row">
      <div class="app-header__title">
        <q-btn
          flat
          round
          dense
          size="xs"
          icon="bi-fullscreen"
          @click="toggleFullscreen"
        />
        <span class="app-header__title-text q-ml-lg">{{ pageTitle }}</span>
      </div>

      <q-space />

      <div class="app-header__actions">
        <!-- Only shown on small screens: the drawer's own toggle (top of
             the drawer) isn't reachable once the drawer is closed. -->
        <q-btn
          flat
          round
          dense
          icon="bi-list"
          class="app-header__mobile-toggle"
          aria-label="باز و بسته کردن منو"
          @click="$emit('toggle-drawer')"
        />

        <!-- 3 example action buttons — add the rest of your header buttons
             here, next to these. -->

        <header-balance-button :amount="54121504" />
        <header-online-credit-button class="q-ml-sm"/>
        <header-dropdown-stat :text="clockLabel" class="q-ml-lg"/>
        <header-dropdown-stat icon="bi-gear" />
      </div>
    </q-toolbar>
  </q-header>
</template>

<style scoped>
.app-header {
  background: var(--header-bg);
  color: var(--header-title-color);
}

.app-header__row {
  min-height: var(--header-height);
  border: none!important;
}

.app-header__title {
  display: flex;
  align-items: center;
  gap: 8px;
}

.app-header__title-text {
  font-weight: 400;
  font-size: 16px;
  color: var(--header-title-color);
}

.app-header__actions {
  display: flex;
  align-items: center;
  gap: 6px;
}

.app-header__mobile-toggle {
  display: none;
}

.app-header__breadcrumbs-row {
  min-height: 32px;
  color: var(--header-breadcrumb-color);
  font-size: 12px;
}

.app-header__breadcrumbs :deep(.q-breadcrumbs__el) {
  color: inherit;
}

@media (max-width: 1023px) {
  .app-header__mobile-toggle {
    display: inline-flex;
  }
}
</style>
